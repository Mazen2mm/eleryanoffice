const EXT_API_BASE = "https://eleryanoffice.vercel.app";
const CHECK_INTERVAL_MINUTES = 1.5;
const ALARM_NAME = "eta-license-check";

const ETA_HOST_MATCH = "https://invoicing.eta.gov.eg/*";

chrome.runtime.onInstalled.addListener(() => {
    console.log("ETA Excel Importer Installed");
    chrome.storage.local.set({ etaLicenseActive: false, etaLicenseToken: null });
});

async function verifyWithServer(token) {
    try {
        const res = await fetch(`${EXT_API_BASE}/api/extension/verify`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ token }),
        });
        if (!res.ok && res.status !== 200) return { ok: false, allowed: false };
        const data = await res.json();
        return data;
    } catch (err) {
        console.error("ETA license verify failed:", err);
        return { ok: false, allowed: false, networkError: true };
    }
}

async function broadcastToEtaTabs(message) {
    chrome.tabs.query({ url: ETA_HOST_MATCH }, (tabs) => {
        tabs.forEach((tab) => {
            chrome.tabs.sendMessage(tab.id, message, () => {
                void chrome.runtime.lastError;
            });
        });
    });
}

async function deactivateLicense(reason) {
    await chrome.storage.local.set({ etaLicenseActive: false, etaLicenseToken: null });
    chrome.alarms.clear(ALARM_NAME);
    await broadcastToEtaTabs({ action: "ETA_DEACTIVATE", reason: reason || "الجلسة انتهت" });
    try {
        chrome.notifications.create({
            type: "basic",
            iconUrl: "icons/icon128.png",
            title: "ETA Excel Importer",
            message: reason || "تم إيقاف الإضافة من لوحة التحكم",
        });
    } catch (e) {}
}

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {

    if (request?.action !== "ETA_ACTIVATE") {
        sendResponse({ allowed: false, message: "Unknown Action" });
        return;
    }

    if (!request.token) {
        sendResponse({ allowed: false, message: "توكن مفقود" });
        return;
    }

    verifyWithServer(request.token).then(async (result) => {
        if (!result.allowed) {
            sendResponse({ allowed: false, message: result.message || "معندكش صلاحية تشغيل الإضافة" });
            return;
        }

        await chrome.storage.local.set({ etaLicenseActive: true, etaLicenseToken: result.token });
        chrome.alarms.create(ALARM_NAME, { periodInMinutes: CHECK_INTERVAL_MINUTES });
        await broadcastToEtaTabs({ action: "ETA_ACTIVATE_OK" });

        sendResponse({ allowed: true });
    });

    return true;

});

chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name !== ALARM_NAME) return;

    const stored = await chrome.storage.local.get(["etaLicenseActive", "etaLicenseToken"]);
    if (!stored.etaLicenseActive || !stored.etaLicenseToken) {
        chrome.alarms.clear(ALARM_NAME);
        return;
    }

    const result = await verifyWithServer(stored.etaLicenseToken);

    if (!result.allowed) {
        await deactivateLicense(result.networkError ? "تعذر التأكد من صلاحية الجلسة - تم الإيقاف احتياطيًا" : (result.message || "الصلاحية اتلغت"));
        return;
    }

    await chrome.storage.local.set({ etaLicenseToken: result.token });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    if (request.action === "TOGGLE_SIDEBAR") {

        chrome.storage.local.get(["etaLicenseActive"], (stored) => {
            if (!stored.etaLicenseActive) {
                sendResponse({ success: false, message: "لازم تفعّل الإضافة من موقع المكتب الأول" });
                return;
            }

            chrome.tabs.query(
                { active: true, currentWindow: true, url: ETA_HOST_MATCH },
                (tabs) => {
                    if (!tabs.length) {
                        sendResponse({ success: false, message: "افتح صفحة ETA أولاً" });
                        return;
                    }
                    chrome.tabs.sendMessage(
                        tabs[0].id,
                        { action: "TOGGLE_SIDEBAR" },
                        () => sendResponse({ success: true })
                    );
                }
            );
        });

        return true;

    }

    if (request.action === "GET_LICENSE_STATUS") {
        chrome.storage.local.get(["etaLicenseActive"], (stored) => {
            sendResponse({ active: !!stored.etaLicenseActive });
        });
        return true;
    }

    sendResponse({ success: false, message: "Unknown Action" });

});
