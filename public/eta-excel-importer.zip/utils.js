
const Utils = {

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    },

    random(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    },

    async waitRandom(min = 300, max = 700) {
        await this.sleep(this.random(min, max));
    },

    click(element) {

        if (!element) return false;

        element.dispatchEvent(new MouseEvent("mouseover", {
            bubbles: true
        }));

        element.dispatchEvent(new MouseEvent("mousedown", {
            bubbles: true
        }));

        element.dispatchEvent(new MouseEvent("mouseup", {
            bubbles: true
        }));

        element.click();

        return true;
    },

    setInputValue(input, value) {

        if (!input) return false;

        input.focus();

        input.value = value;

        input.dispatchEvent(new Event("input", {
            bubbles: true
        }));

        input.dispatchEvent(new Event("change", {
            bubbles: true
        }));

        input.dispatchEvent(new KeyboardEvent("keyup", {
            bubbles: true
        }));

        return true;
    },

    setReactInputValue(input, value) {

        if (!input) return false;

        const proto =
            input.tagName === "TEXTAREA"
                ? window.HTMLTextAreaElement.prototype
                : window.HTMLInputElement.prototype;

        const nativeSetter =
            Object.getOwnPropertyDescriptor(proto, "value").set;

        input.focus();

        nativeSetter.call(input, value);

        input.dispatchEvent(new Event("input", {
            bubbles: true
        }));

        input.dispatchEvent(new Event("change", {
            bubbles: true
        }));

        input.dispatchEvent(new KeyboardEvent("keyup", {
            bubbles: true
        }));

        return true;
    },

    setReactSelectValue(select, value) {

        if (!select) return false;

        const nativeSetter =
            Object.getOwnPropertyDescriptor(
                window.HTMLSelectElement.prototype,
                "value"
            ).set;

        nativeSetter.call(select, value);

        select.dispatchEvent(new Event("input", {
            bubbles: true
        }));

        select.dispatchEvent(new Event("change", {
            bubbles: true
        }));

        return true;
    },

    async retry(fn, attempts = 3, delayMs = 800) {

        let lastError = null;

        for (let i = 0; i < attempts; i++) {

            try {

                return await fn();

            } catch (ex) {

                lastError = ex;
                this.log(`محاولة ${i + 1}/${attempts} فشلت: ${ex.message || ex}`);
                await this.sleep(delayMs);

            }

        }

        throw lastError;

    },

    async type(input, text, delay = 20) {

        input.focus();

        input.value = "";

        for (const char of text.toString()) {

            input.value += char;

            input.dispatchEvent(new Event("input", {
                bubbles: true
            }));

            await this.sleep(delay);

        }

        input.dispatchEvent(new Event("change", {
            bubbles: true
        }));

    },

    isVisible(el) {

        if (!el) return false;
        if (el.offsetParent === null) return false;

        const rect = el.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;

    },

    getVisibleElements(selector) {
        return [...document.querySelectorAll(selector)].filter(el => this.isVisible(el));
    },

    firstVisible(selector) {
        return this.getVisibleElements(selector)[0] || null;
    },

    waitForVisibleSelector(selector, timeout = 10000) {

        return new Promise((resolve, reject) => {

            const start = Date.now();

            const timer = setInterval(() => {

                const el = this.firstVisible(selector);

                if (el) {
                    clearInterval(timer);
                    resolve(el);
                    return;
                }

                if (Date.now() - start > timeout) {
                    clearInterval(timer);
                    reject("Visible selector not found: " + selector);
                }

            }, 250);

        });

    },

    waitForSelector(selector, timeout = 10000) {

        return new Promise((resolve, reject) => {

            const timer = setInterval(() => {

                const el = document.querySelector(selector);

                if (el) {

                    clearInterval(timer);

                    resolve(el);

                }

            }, 300);

            setTimeout(() => {

                clearInterval(timer);

                reject("Selector Not Found : " + selector);

            }, timeout);

        });

    },

    normalizeText(text) {
        return (text || "").replace(/\s+/g, " ").trim();
    },

    findButtonByText(text, scope) {

        const target = this.normalizeText(text);

        const root =
            (typeof scope === "string" ? document.querySelector(scope) : scope)
            || document;

        const candidates = [...root.querySelectorAll(
            "button, [role='button'], a.ms-Button, .ms-Button"
        )];

        const exact = candidates.filter(
            btn => this.normalizeText(btn.innerText || btn.textContent) === target
        );

        if (exact.length) {
            return exact.find(btn => this.isVisible(btn)) || exact.filter(b => this.isVisible(b))[0] || null;
        }

        const partial = candidates
            .filter(btn => this.normalizeText(btn.innerText || btn.textContent).includes(target))
            .sort((a, b) =>
                this.normalizeText(a.innerText || a.textContent).length -
                this.normalizeText(b.innerText || b.textContent).length
            );

        if (!partial.length) return null;

        return partial.find(btn => this.isVisible(btn)) || null;

    },

    async waitForButtonByText(text, timeout = 10000, scope) {

        const start = Date.now();

        while (Date.now() - start < timeout) {

            const btn = this.findButtonByText(text, scope);
            if (btn) return btn;

            await this.sleep(200);

        }

        throw new Error("Button not found: " + text);

    },

    pressEnter(input) {

        if (!input) return false;

        const opts = {
            key: "Enter",
            code: "Enter",
            keyCode: 13,
            which: 13,
            bubbles: true
        };

        input.dispatchEvent(new KeyboardEvent("keydown", opts));
        input.dispatchEvent(new KeyboardEvent("keypress", opts));
        input.dispatchEvent(new KeyboardEvent("keyup", opts));

        return true;
    },

    climbToSharedContainer(el, minInputs = 2, maxLevels = 6) {

        let node = el;

        for (let i = 0; i < maxLevels && node; i++) {

            if (node.querySelectorAll("input").length >= minInputs) {
                return node;
            }

            node = node.parentElement;

        }

        return el.parentElement || el;

    },

    findFieldNearText(scope, keywords, tag = "input") {

        const root =
            (typeof scope === "string" ? document.querySelector(scope) : scope)
            || document;

        if (!root) return null;

        const normKeywords = keywords.map(k => this.normalizeText(k));

        const candidates = [...root.querySelectorAll("span, div, button, label, p")];

        for (const el of candidates) {

            const ownText = this.normalizeText(el.textContent);

            if (!ownText || ownText.length > 10) continue;

            if (!normKeywords.some(k => ownText === k || ownText.includes(k))) continue;

            let container = el;

            for (let i = 0; i < 4 && container; i++) {

                const field = container.querySelector(tag);

                if (field && this.isVisible(field)) {
                    return field;
                }

                container = container.parentElement;

            }

        }

        return null;

    },

    findFieldByLabel(scope, keywords, tag = "input") {

        const root =
            (typeof scope === "string" ? document.querySelector(scope) : scope)
            || document;

        if (!root) return null;

        const normKeywords = keywords.map(k => this.normalizeText(k));

        const labels = [...root.querySelectorAll("label, .ms-Label")];

        for (const label of labels) {

            const labelText = this.normalizeText(label.textContent);

            if (!normKeywords.some(k => labelText.includes(k))) continue;

            const container =
                label.closest(".ms-TextField, .ms-Dropdown, .ms-ComboBox, .ms-Stack") ||
                label.parentElement;

            if (!container) continue;

            const field = container.querySelector(tag);

            if (field && this.isVisible(field)) {
                return field;
            }

        }

        return null;

    },

    async selectFluentOption(trigger, optionText, timeout = 8000, factor = 1) {

        if (!trigger) throw new Error("Dropdown trigger not found");

        const target = this.normalizeText(optionText);

        this.click(trigger);
        await this.sleep(300 * factor);

        const start = Date.now();
        let option = null;

        while (Date.now() - start < timeout) {

            const all = [...document.querySelectorAll(
                ".ms-Dropdown-optionText, .ms-ComboBox-optionText, [role='option']"
            )];

            let matches = all.filter(o => this.normalizeText(o.textContent) === target);

            if (!matches.length) {
                matches = all
                    .filter(o => this.normalizeText(o.textContent).includes(target))
                    .sort((a, b) => this.normalizeText(a.textContent).length - this.normalizeText(b.textContent).length);
            }

            option = matches.find(o => this.isVisible(o)) || matches[0] || null;

            if (option) break;

            await this.sleep(150);

        }

        if (!option) {
            throw new Error(`لم يتم إيجاد الاختيار "${optionText}" في القائمة المنسدلة`);
        }

        this.click(option);
        await this.sleep(250 * factor);

        return true;

    },

    async waitForNewElements(selector, beforeSet, count = 1, timeout = 6000) {

        const start = Date.now();

        while (Date.now() - start < timeout) {

            const current = [...document.querySelectorAll(selector)];
            const fresh = current.filter(el => !beforeSet.has(el));

            if (fresh.length >= count) return fresh;

            await this.sleep(150);

        }

        throw new Error("لم تظهر عناصر جديدة (" + selector + ") في الوقت المحدد");

    },

    log(message) {

        console.log(
            "%cETA Importer",
            "color:#1976d2;font-weight:bold;",
            message
        );

    },

    error(message) {

        console.error(
            "%cETA Importer",
            "color:red;font-weight:bold;",
            message
        );

    },

    progress(current, total) {

        const percent = Math.round(
            (current / total) * 100
        );

        console.log(
            `[${current}/${total}] ${percent}%`
        );

    }

};

window.Utils = Utils;