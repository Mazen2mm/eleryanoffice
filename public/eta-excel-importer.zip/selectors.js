const ETA_SELECTORS = {

    panel: ".ms-Panel.LineDetails",

    cancelButtonText: "إلغاء",

    codeTypeSelect: ".ItemCodeContainer span.ms-Dropdown-title",

    openItemModalButtonText: "اضافة تفاصيل",

    codeTypeValueEGS: "EGS",

    codeTypeValueGS1: "GS1",

    codeInput: ".ItemCodeContainer input.ms-ComboBox-Input",

    searchButton: ".ms-Panel.LineDetails button.searchComboBox-searchButton",

    itemNameDisplay: ".ms-Panel.LineDetails .ms-Label",

    itemNotFoundIndicator: ".eta-item-not-found",

    descriptionInput: ".ms-Panel.LineDetails textarea.ms-TextField-field",

    quantityInput: '.ms-Panel.LineDetails input[id$="_quantity_fields"]',

    priceInput: '.ms-Panel.LineDetails input[id$="_amountEGPCustom"]',

    discountInput: '.ms-Panel.LineDetails input[id*="discount"],.ms-Panel.LineDetails input[id*="Discount"]',

    addTaxButtonText: "أضف الضريبة",

    addItemButtonText: "أضف",

    dropdownTrigger: ".ms-Panel.LineDetails span.ms-Dropdown-title",

    taxCodes: {

        vat: {
            type: "T1",
            subType: "V009",
            rate: 14
        },

        withholdingSupplies: {
            type: "T4",
            subType: "W002",
            rate: 1
        },

        withholdingServices: {
            type: "T4",
            subType: "W004",
            rate: 3
        }

    }

};