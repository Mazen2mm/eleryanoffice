
(() => {

    console.log("%cETA Excel Importer Injected",
        "color:#1976d2;font-size:14px;font-weight:bold;");

    window.ETA_IMPORTER = {

        version: "1.0.0",

        notify(message) {
            console.log("[ETA]", message);
        },

        wait(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }

    };

    window.addEventListener("message", (event) => {

        if (event.source !== window)
            return;

        if (!event.data)
            return;

        switch (event.data.action) {

            case "PING":

                window.postMessage({
                    action: "PONG"
                }, "*");

                break;

            case "START":

                console.log("ETA Import Started");

                break;

        }

    });

})();