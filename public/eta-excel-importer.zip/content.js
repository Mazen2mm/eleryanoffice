(function () {

    if (document.getElementById("eta-sidebar")) return;

    let ETA_LICENSE_ACTIVE = false;

    chrome.storage.local.get(["etaLicenseActive"], (res) => {
        ETA_LICENSE_ACTIVE = !!res.etaLicenseActive;
        etaApplyLicenseUI();
    });

    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && Object.prototype.hasOwnProperty.call(changes, "etaLicenseActive")) {
            ETA_LICENSE_ACTIVE = !!changes.etaLicenseActive.newValue;
            etaApplyLicenseUI();
        }
    });

    function etaApplyLicenseUI() {
        const openerEl = document.getElementById("eta-open");
        if (!openerEl) return;
        openerEl.style.display = ETA_LICENSE_ACTIVE ? "" : "none";
        if (!ETA_LICENSE_ACTIVE) {
            const sb = document.getElementById("eta-sidebar");
            if (sb) sb.classList.remove("open");
        }
    }

    const etaLogoUrl = chrome.runtime.getURL("assets/logo.png");

    const opener = document.createElement("div");
    opener.id = "eta-open";
    opener.style.display = "none";
    opener.innerHTML = `
        <span class="eta-open-ring"></span>
        <img src="${etaLogoUrl}" class="eta-open-logo" alt="">
    `;
    document.body.appendChild(opener);

    const sidebar = document.createElement("div");
    sidebar.id = "eta-sidebar";
    sidebar.innerHTML = `

        <div class="eta-header">
            <div class="eta-header-glow"></div>
            <button id="eta-sidebar-close" class="eta-sidebar-close" title="إغلاق">
                <span>✕</span>
            </button>
            <div class="eta-header-row">
                <img src="${etaLogoUrl}" class="eta-header-logo" alt="">
                <div>
                    <h2>ETA Excel Importer</h2>
                    <small>By Mazen Eleryan</small>
                </div>
            </div>
        </div>

        <div class="eta-body">

            <label>ملف Excel</label>
            <input type="file" id="eta-file" accept=".xlsx,.xls">
            <div id="eta-file-info" class="eta-file-info"></div>

            <div class="eta-check">
                <input type="checkbox" id="eta-vat" checked>
                ضريبة القيمة المضافة VAT (14%)
            </div>

            <div class="eta-check">
                <input type="checkbox" id="eta-with">
                ضريبة الخصم والإضافة
            </div>

            <div id="eta-with-box" style="display:none;">
                <label>النوع</label>
                <select id="eta-with-type">
                    <option value="supplies">توريدات (1%)</option>
                    <option value="services">خدمات (3%)</option>
                </select>
            </div>

            <label>نوع الوحدة</label>
                <input
                    id="eta-unit-type"
                    type="text"
                    placeholder="مثال: EA each (ST)"
                    value="EA each (ST)"
                >

            <label>خصم على الصنف</label>
            <select id="eta-dis">
                <option value="0">لا</option>
                <option value="1">نعم</option>
            </select>

            <input
                id="eta-dis-value"
                type="number"
                placeholder="قيمة الخصم"
                style="display:none;"
            >

            <label>سرعة التنفيذ</label>
            <select id="eta-speed">
                <option value="slow">Slow</option>
                <option value="normal" selected>Normal</option>
                <option value="fast">Fast</option>
                <option value="veryfast">Very Fast</option>
            </select>

            <button class="eta-btn" id="eta-start">START IMPORT</button>

            <div id="eta-actions-row" class="eta-actions-row" style="display:none;">
                <button id="eta-pause-btn" class="eta-mini-btn eta-pause-color">Pause</button>
                <button id="eta-stop-btn" class="eta-mini-btn eta-stop-color">Stop</button>
            </div>

            <div id="eta-log-box" class="eta-log-box" style="display:none;">
                <div class="eta-log-title">Error Log</div>
                <div id="eta-log-list"></div>
            </div>

            <div class="eta-footer">By Mazen Eleryan</div>

        </div>

    `;
    document.body.appendChild(sidebar);

    document.getElementById("eta-sidebar-close").onclick = () => {
        sidebar.classList.remove("open");
    };

    (function etaMakeOpenerDraggable() {

        const STORAGE_KEY = "etaOpenerTop";
        let dragging = false;
        let moved = false;
        let startY = 0;
        let startTop = 0;

        function clampTop(top) {
            const min = 10;
            const max = window.innerHeight - opener.offsetHeight - 10;
            return Math.min(Math.max(top, min), max);
        }

        function applyTop(top) {
            opener.style.top = clampTop(top) + "px";
        }

        chrome.storage && chrome.storage.local && chrome.storage.local.get([STORAGE_KEY], (res) => {
            if (res && typeof res[STORAGE_KEY] === "number") {
                applyTop(res[STORAGE_KEY]);
            }
        });

        opener.addEventListener("pointerdown", (e) => {
            dragging = true;
            moved = false;
            startY = e.clientY;
            startTop = opener.getBoundingClientRect().top;
            opener.setPointerCapture(e.pointerId);
            opener.classList.add("eta-dragging");
        });

        opener.addEventListener("pointermove", (e) => {
            if (!dragging) return;
            const delta = e.clientY - startY;
            if (Math.abs(delta) > 4) moved = true;
            applyTop(startTop + delta);
        });

        function endDrag() {
            if (!dragging) return;
            dragging = false;
            opener.classList.remove("eta-dragging");

            if (moved) {
                const finalTop = parseFloat(opener.style.top);
                chrome.storage && chrome.storage.local && chrome.storage.local.set({ [STORAGE_KEY]: finalTop });
            }
        }

        opener.addEventListener("pointerup", endDrag);
        opener.addEventListener("pointercancel", endDrag);

        opener.addEventListener("click", () => {
            if (moved) {
                moved = false;
                return;
            }
            sidebar.classList.toggle("open");
        });

    })();

    document.getElementById("eta-with").onchange = function () {
        document.getElementById("eta-with-box").style.display =
            this.checked ? "block" : "none";
    };

    document.getElementById("eta-dis").onchange = function () {
        document.getElementById("eta-dis-value").style.display =
            this.value === "1" ? "block" : "none";
    };

    function etaCreateProgress() {

        if (document.getElementById("eta-progress")) return;

        const box = document.createElement("div");
        box.id = "eta-progress";

        box.innerHTML = `
            <div class="eta-progress-header">
                <div class="eta-loader-wrap" id="eta-loader-wrap">
                    <div class="eta-loader-ring"></div>
                    <div class="eta-loader-ring eta-loader-ring-2"></div>
                    <img src="${etaLogoUrl}" class="eta-loader-logo" alt="">
                </div>
                <h3>ETA Excel Importer</h3>
            </div>

            <div id="eta-status">Ready...</div>

            <div id="eta-bar">
                <div id="eta-bar-fill"></div>
            </div>

            <div id="eta-progress-count" style="margin-top:8px;text-align:center;color:#555;">
                0 / 0
            </div>

            <div id="eta-actions">
                <button id="eta-pause">Pause</button>
                <button id="eta-stop">Stop</button>
                <button id="eta-close" style="display:none;">Close</button>
            </div>

            <div id="eta-mini-log"></div>

            <div id="eta-watermark">By Mazen Eleryan</div>
        `;

        document.body.appendChild(box);

        document.getElementById("eta-pause").onclick = etaTogglePause;
        document.getElementById("eta-stop").onclick = etaStopImport;
        document.getElementById("eta-close").onclick = etaHideProgress;
    }

    etaCreateProgress();

    function etaShowProgress() {
        const box = document.getElementById("eta-progress");
        box.style.display = "block";
        box.classList.remove("eta-pop-in");
        void box.offsetWidth;
        box.classList.add("eta-pop-in");
    }

    function etaHideProgress() {
        document.getElementById("eta-progress").style.display = "none";
    }

    function etaUpdateProgress() {

        const percent = ETA.total === 0
            ? 0
            : Math.round((ETA.current / ETA.total) * 100);

        document.getElementById("eta-bar-fill").style.width = percent + "%";
        document.getElementById("eta-progress-count").innerHTML =
            ETA.current + " / " + ETA.total;

        const done = ETA.current >= ETA.total && ETA.total > 0;

        document.getElementById("eta-status").innerHTML =
            ETA.stopped
                ? "تم الإيقاف"
                : ETA.paused
                    ? "متوقف مؤقتًا (Paused)"
                    : done
                        ? "اكتمل الاستيراد ✔"
                        : `جاري الاستيراد... (${percent}%)`;

        const loader = document.getElementById("eta-loader-wrap");

        if (loader) {
            loader.classList.toggle("eta-spinning", ETA.running && !ETA.paused && !ETA.stopped && !done);
            loader.classList.toggle("eta-paused", ETA.paused);
            loader.classList.toggle("eta-done", done || ETA.stopped);
        }
    }

    function etaAddLogEntry(rowIndex, rowData, message, type = "error") {

        ETA.errorLog.push({
            row: rowIndex + 1,
            code: rowData ? (rowData["Item Code"] ?? rowData["Code"] ?? "") : "",
            message,
            type
        });

        const logBox = document.getElementById("eta-log-box");
        const logList = document.getElementById("eta-log-list");
        const miniLog = document.getElementById("eta-mini-log");

        logBox.style.display = "block";

        const line = document.createElement("div");
        line.className = "eta-log-line eta-log-" + type;
        line.innerHTML =
            `<b>صف ${rowIndex + 1}</b> (${line_codeSafe(rowData)}): ${message}`;

        logList.appendChild(line);
        miniLog.innerHTML =
            `<div class="eta-mini-log-line">صف ${rowIndex + 1}: ${message}</div>` +
            miniLog.innerHTML;
    }

    function line_codeSafe(rowData) {
        if (!rowData) return "-";
        return rowData["Item Code"] ?? rowData["Code"] ?? "-";
    }

    let etaRows = [];

    const ETA = {
        running: false,
        paused: false,
        stopped: false,
        current: 0,
        total: 0,
        file: null,
        settings: {},
        errorLog: []
    };

    function etaReadExcel(file) {

        return new Promise((resolve, reject) => {

            const reader = new FileReader();

            reader.onload = function (e) {

                try {

                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: "array" });
                    const sheet = workbook.Sheets[workbook.SheetNames[0]];

                    const rows = XLSX.utils.sheet_to_json(sheet, {
                        defval: ""
                    });

                    resolve(rows);

                } catch (ex) {
                    reject(ex);
                }

            };

            reader.onerror = reject;
            reader.readAsArrayBuffer(file);

        });

    }

    document.getElementById("eta-file").addEventListener("change", async function () {

        if (!this.files.length) return;

        ETA.file = this.files[0];

        const info = document.getElementById("eta-file-info");
        info.innerHTML = "جاري قراءة الملف...";

        try {

            const rows = await etaReadExcel(ETA.file);

            etaRows = rows;
            ETA.total = rows.length;
            ETA.current = 0;

            info.innerHTML = `تم تحميل ${rows.length} صنف بنجاح ✔`;

        } catch (ex) {

            info.innerHTML = "فشل قراءة الملف";
            Utils.error(ex);
            alert("تعذر قراءة ملف Excel: " + ex);

        }

    });
        function etaCollectSettings() {

            ETA.settings = {

                vat: document.getElementById("eta-vat").checked,

                withholding: document.getElementById("eta-with").checked,

                withholdingType: document.getElementById("eta-with-type").value,

                
                unitType: document.getElementById("eta-unit-type").value.trim(),

                discount:
                    document.getElementById("eta-dis").value === "1"
                        ? Number(document.getElementById("eta-dis-value").value || 0)
                        : 0,

                speed: document.getElementById("eta-speed").value

            };

        }

    function etaGetDelay() {

        switch (ETA.settings.speed) {
            case "veryfast": return { step: 18, afterSearch: 90, afterAdd: 60, factor: 0.12 };
            case "fast": return { step: 45, afterSearch: 200, afterAdd: 150, factor: 0.3 };
            case "normal": return { step: 90, afterSearch: 400, afterAdd: 300, factor: 0.6 };
            case "slow": return { step: 150, afterSearch: 600, afterAdd: 500, factor: 1 };
            default: return { step: 150, afterSearch: 600, afterAdd: 500, factor: 1 };
        }

    }

    async function etaWaitWhilePaused() {

        while (ETA.paused && !ETA.stopped) {
            await Utils.sleep(300);
        }

    }

    function etaTogglePause() {

        if (!ETA.running) return;

        ETA.paused = !ETA.paused;

        document.getElementById("eta-pause").innerText =
            ETA.paused ? "Resume" : "Pause";

        document.getElementById("eta-pause-btn").innerText =
            ETA.paused ? "Resume" : "Pause";

        etaUpdateProgress();

    }

    function etaStopImport() {

        if (!ETA.running) return;

        const sure = confirm("هل أنت متأكد من إيقاف الاستيراد؟");
        if (!sure) return;

        ETA.stopped = true;
        ETA.paused = false;
        etaUpdateProgress();
        etaFinishImport();

    }

    function etaFinishImport() {

        ETA.running = false;

        document.getElementById("eta-start").disabled = false;
        document.getElementById("eta-start").innerText = "START IMPORT";
        document.getElementById("eta-actions-row").style.display = "none";
        document.getElementById("eta-close").style.display = "inline-block";

        etaUpdateProgress();

        const successCount = ETA.current - ETA.errorLog.filter(e => e.type === "error").length;

        Utils.log(
            `Import Finished. Success: ${successCount} / ${ETA.total}, Errors: ${ETA.errorLog.length}`
        );

    }

    async function etaCloseModalIfOpen() {

        const panel = document.querySelector(ETA_SELECTORS.panel);

        if (!panel || !Utils.isVisible(panel)) return;

        const cancelBtn = Utils.findButtonByText(ETA_SELECTORS.cancelButtonText, panel);

        if (cancelBtn) {
            Utils.click(cancelBtn);
        }

        const start = Date.now();

        while (Date.now() - start < 5000) {

            const p = document.querySelector(ETA_SELECTORS.panel);
            if (!p || !Utils.isVisible(p)) return;

            await Utils.sleep(200);

        }

    }

    async function etaOpenItemModal(delays) {

        const factor = delays ? delays.factor : 1;

        await etaCloseModalIfOpen();
        await Utils.sleep(300 * factor);

        const btn = await Utils.waitForButtonByText(ETA_SELECTORS.openItemModalButtonText, 8000)
            .catch(() => null);

        if (!btn) {
            throw new Error(`لم يتم العثور على زر "${ETA_SELECTORS.openItemModalButtonText}" - راجع selectors.js`);
        }

        Utils.click(btn);

        await Utils.waitForVisibleSelector(ETA_SELECTORS.codeTypeSelect, 8000)
            .catch(() => {
                throw new Error("نافذة إضافة الصنف (Modal) متفتحتش بعد الضغط على \"" + ETA_SELECTORS.openItemModalButtonText + "\" - راجع selectors.js");
            });

        await Utils.sleep(300 * factor);

        await etaClearModalFields();

    }

    async function etaClearModalFields() {

        const codeInput = Utils.firstVisible(ETA_SELECTORS.codeInput);
        if (codeInput && codeInput.value) {
            Utils.setReactInputValue(codeInput, "");
            await Utils.sleep(150);
        }

        const descInput = Utils.firstVisible(ETA_SELECTORS.descriptionInput);
        if (descInput && descInput.value) {
            Utils.setReactInputValue(descInput, "");
        }

        const qtyInput = Utils.firstVisible(ETA_SELECTORS.quantityInput);
        if (qtyInput && qtyInput.value) {
            Utils.setReactInputValue(qtyInput, "");
        }

        const priceInput = Utils.firstVisible(ETA_SELECTORS.priceInput);
        if (priceInput && priceInput.value) {
            Utils.setReactInputValue(priceInput, "");
        }

        const discountInput = Utils.firstVisible(ETA_SELECTORS.discountInput);
        if (discountInput && discountInput.value) {
            Utils.setReactInputValue(discountInput, "");
        }

    }

    async function etaSelectCodeType(codeType, delays) {

        const el = await Utils.waitForVisibleSelector(ETA_SELECTORS.codeTypeSelect, 5000)
            .catch(() => null);

        if (!el) {
            throw new Error("لم يتم العثور على حقل نوع الكود (codeTypeSelect) - راجع selectors.js");
        }

        const value =
            codeType === "GS1"
                ? ETA_SELECTORS.codeTypeValueGS1
                : ETA_SELECTORS.codeTypeValueEGS;

        await Utils.selectFluentOption(el, value, 8000, delays ? delays.factor : 1);

    }

    async function etaEnterCode(code, delays) {

        const factor = delays ? delays.factor : 1;

        const input = await Utils.waitForVisibleSelector(ETA_SELECTORS.codeInput, 5000)
            .catch(() => null);

        if (!input) {
            throw new Error("لم يتم العثور على حقل كود الصنف (codeInput) - راجع selectors.js");
        }

        const beforeCandidates = new Set(
            document.querySelectorAll("li, div, span, a, button")
        );

        Utils.setReactInputValue(input, code);

        await Utils.sleep(300 * factor);

        return { input, beforeCandidates };

    }

    async function etaClickSearchResult(code, beforeCandidates, factor = 1, timeout = 8000) {

        const target = "EG-" + Utils.normalizeText(code).trim();
        const start = Date.now();

        while (Date.now() - start < timeout) {

            const all = [...document.querySelectorAll("b.BolderCode")];
            const codeElement = all.find(x => Utils.normalizeText(x.innerText) === target);

            if (codeElement) {
                Utils.log(`تم اختيار نتيجة البحث: "${codeElement.innerText}"`);
                Utils.click(codeElement.closest("li, div, button, a") || codeElement.parentElement);
                await Utils.sleep(400 * factor);
                return true;
            }

            await Utils.sleep(200);
        }

        const targetPlain = Utils.normalizeText(code);

        const candidates = [...document.querySelectorAll("li, div, span, a, button")]
            .filter(el => !beforeCandidates || !beforeCandidates.has(el))
            .filter(el => Utils.isVisible(el))
            .filter(el => Utils.normalizeText(el.textContent).includes(targetPlain))
            .sort((a, b) =>
                Utils.normalizeText(a.textContent).length -
                Utils.normalizeText(b.textContent).length
            );

        if (candidates.length) {
            Utils.log(`تم اختيار نتيجة البحث (fallback): "${Utils.normalizeText(candidates[0].textContent)}"`);
            Utils.click(candidates[0]);
            await Utils.sleep(400 * factor);
            return true;
        }

        return false;

    }
    async function etaClickSearch(factor = 1) {

        const selector = "button.searchComboBox-searchButton";
        const start = Date.now();
        const timeout = 6000;

        let btn = null;

        while (Date.now() - start < timeout) {

            btn = document.querySelector(`${ETA_SELECTORS.panel} ${selector}`) ||
                  document.querySelector(selector);

            if (btn && Utils.isVisible(btn) && !btn.disabled) {
                break;
            }

            btn = null;
            await Utils.sleep(150);

        }

        if (!btn) {
            Utils.log("زر البحث مش موجود دلوقتي - هيتم تخطيه");
            return;
        }

        Utils.log("تم الضغط على زر البحث");
        Utils.click(btn);
        await Utils.sleep(200 * factor);

    }

    async function etaWaitForItemSelected(delays) {

        const start = Date.now();
        const timeout = Math.max(delays.afterSearch * 4, 6000);

        while (Date.now() - start < timeout) {

            const descInput = Utils.firstVisible(ETA_SELECTORS.descriptionInput);

            if (descInput && descInput.value && descInput.value.trim() !== "") {
                return descInput.value.trim();
            }

            const qtyInput = Utils.firstVisible(ETA_SELECTORS.quantityInput);

            if (qtyInput && !qtyInput.disabled) {
                return descInput ? (descInput.value || "").trim() : "";
            }

            await Utils.sleep(80);
        }

        console.warn("ETA: Item name timeout, continue...");
        return "";
    }

    async function etaFillDescription(descriptionFromExcel, etaItemName) {

        const finalDescription =
            descriptionFromExcel && descriptionFromExcel.toString().trim() !== ""
                ? descriptionFromExcel.toString().trim()
                : etaItemName;

        if (!finalDescription) return;

        const input = Utils.firstVisible(ETA_SELECTORS.descriptionInput);

        if (input) {
            Utils.setReactInputValue(input, finalDescription);
        }

    }

    async function etaFillQuantity(qty) {

        const input = await Utils.waitForVisibleSelector(ETA_SELECTORS.quantityInput, 5000)
            .catch(() => null);

        if (!input) {
            throw new Error("لم يتم العثور على حقل الكمية (quantityInput) - راجع selectors.js");
        }

        Utils.setReactInputValue(input, qty);

    }

    async function etaFillUnitType(value) {

        if (!value) return;

        const input = document.querySelectorAll('input.ms-ComboBox-Input')[5];

        if (!input) return;

        input.focus();

        input.value = value;

        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));

        await Utils.sleep(300);

    }

    async function etaFillPrice(price) {

        const input = await Utils.waitForVisibleSelector(ETA_SELECTORS.priceInput, 5000)
            .catch(() => null);

        if (!input) {
            throw new Error("لم يتم العثور على حقل السعر (priceInput) - راجع selectors.js");
        }

        Utils.setReactInputValue(input, price);

    }

    async function etaFillDiscount(discountValue) {

        if (!discountValue || Number(discountValue) <= 0) return;

        const egpInput = Utils.firstVisible(ETA_SELECTORS.discountInput);

        if (!egpInput) {
            throw new Error("لم يتم العثور على قسم الخصم (discountInput) - راجع selectors.js");
        }

        const section = Utils.climbToSharedContainer(egpInput, 2, 6);

        let percentInput = Utils.findFieldNearText(section, ["%", "٪", "نسبة"], "input");

        if (!percentInput) {
            percentInput = [...section.querySelectorAll("input")]
                .find(i => i !== egpInput && Utils.isVisible(i)) || null;
        }

        if (!percentInput) {
            throw new Error("لم يتم العثور على حقل الخصم بالنسبة المئوية - راجع discountInput/selectors.js");
        }

        Utils.setReactInputValue(percentInput, discountValue);

    }

    async function etaAddTaxLine({ type, subType, rate }, delays) {

        const factor = delays ? delays.factor : 1;

        const panel = document.querySelector(ETA_SELECTORS.panel);

        const beforeDropdowns = new Set(
            document.querySelectorAll(ETA_SELECTORS.dropdownTrigger)
        );

        const beforeInputs = new Set(
            (panel || document).querySelectorAll("input")
        );

        const addBtn = await Utils.waitForButtonByText(
            ETA_SELECTORS.addTaxButtonText, 5000, ETA_SELECTORS.panel
        ).catch(() => null);

        if (!addBtn) {
            throw new Error(`لم يتم العثور على زر "${ETA_SELECTORS.addTaxButtonText}" - راجع selectors.js`);
        }

        Utils.click(addBtn);
        await Utils.sleep(500 * factor);

        const [typeDropdown, subTypeDropdown] = await Utils.waitForNewElements(
            ETA_SELECTORS.dropdownTrigger,
            beforeDropdowns,
            2,
            6000
        ).catch(() => {
            throw new Error("لم يظهر Dropdown نوع/فئة الضريبة بعد الضغط على أضف الضريبة - راجع dropdownTrigger في selectors.js");
        });

        await Utils.selectFluentOption(typeDropdown, type, 8000, factor);
        await Utils.sleep(300 * factor);

        await Utils.selectFluentOption(subTypeDropdown, subType, 8000, factor);
        await Utils.sleep(500 * factor);

        await Utils.sleep(400 * factor);

        const newInputs = [...(panel || document).querySelectorAll("input")]
            .filter(i => !beforeInputs.has(i) && Utils.isVisible(i));

        let rateInput = null;

        if (newInputs.length) {

            const section = Utils.climbToSharedContainer(newInputs[0], 2, 6);

            rateInput = Utils.findFieldNearText(section, ["%", "٪", "معدل"], "input");

            if (rateInput && !newInputs.includes(rateInput)) {
                rateInput = null;
            }

        }

        if (!rateInput && newInputs.length) {
            rateInput = newInputs[0];
        }

        if (rateInput) {
            Utils.setReactInputValue(rateInput, rate);
            await Utils.sleep(250 * factor);
            Utils.pressEnter(rateInput);
            await Utils.sleep(300 * factor);
        }

    }

    async function etaClickAdd(delays) {

        const btn = await Utils.waitForButtonByText(
            ETA_SELECTORS.addItemButtonText, 5000, ETA_SELECTORS.panel
        ).catch(() => null);

        if (!btn) {
            throw new Error(`لم يتم العثور على زر "${ETA_SELECTORS.addItemButtonText}" - راجع selectors.js`);
        }

        Utils.click(btn);

        await Utils.sleep(delays.afterAdd);

        const panel = document.querySelector(ETA_SELECTORS.panel);

        if (panel && Utils.isVisible(panel)) {

            Utils.log("النافذة فضلت فاتحة بعد \"أضف\" - بنقفلها إجباريًا قبل الصنف اللي بعده");

            const cancelBtn = Utils.findButtonByText(ETA_SELECTORS.cancelButtonText, panel);

            if (cancelBtn) {
                Utils.click(cancelBtn);
            }

            const start = Date.now();
            while (Date.now() - start < 5000) {
                const p = document.querySelector(ETA_SELECTORS.panel);
                if (!p || !Utils.isVisible(p)) break;
                await Utils.sleep(200);
            }

        }

    }

    async function etaProcessRowOnce(row, index, delays) {

        await etaWaitWhilePaused();
        if (ETA.stopped) return;

        const code = row["Item Code"] ?? row["Code"] ?? "";
        const description = row["Description"] ?? "";
        const qty = row["Quantity"] ?? row["Qty"] ?? 0;
        const price = row["Price"] ?? row["Unit Price"] ?? 0;

        if (!code) {
            throw new Error("الصف لا يحتوي على Item Code");
        }

        Utils.log(`صف ${index + 1}: فتح نافذة التفاصيل...`);
        await etaOpenItemModal(delays);
        await Utils.sleep(delays.step);

        Utils.log(`صف ${index + 1}: اختيار نوع الكود EGS...`);
        await etaSelectCodeType("EGS", delays);
        await Utils.sleep(delays.step);

        Utils.log(`صف ${index + 1}: كتابة الكود ${code}...`);
        const { beforeCandidates } = await etaEnterCode(code, delays);

        Utils.log(`صف ${index + 1}: الضغط على زر البحث...`);
        await etaClickSearch(delays.factor);

        Utils.log(`صف ${index + 1}: البحث عن نفس الكود في النتائج...`);
        const selected = await etaClickSearchResult(code, beforeCandidates, delays.factor);

        if (!selected) {
            Utils.log(`صف ${index + 1}: مالقيتش نتيجة مطابقة للكود ${code} بعد البحث`);
        }

        Utils.log(`صف ${index + 1}: انتظار اختيار الصنف...`);
        const etaItemName = await etaWaitForItemSelected(delays);
        Utils.log(`صف ${index + 1}: اسم الصنف = "${etaItemName}"`);

        Utils.log(`صف ${index + 1}: تعبئة الوصف...`);
        await etaFillDescription(description, etaItemName);
        await Utils.sleep(delays.step);

        Utils.log(`صف ${index + 1}: تعبئة الكمية...`);
        await etaFillQuantity(qty);
        await Utils.sleep(delays.step);

        Utils.log(`صف ${index + 1}: تعبئة نوع الوحدة...`);
        await etaFillUnitType(ETA.settings.unitType);
        await Utils.sleep(delays.step);

        Utils.log(`صف ${index + 1}: تعبئة السعر...`);
        await etaFillPrice(price);
        await Utils.sleep(delays.step);

        if (ETA.settings.discount > 0) {
            Utils.log(`صف ${index + 1}: تعبئة الخصم...`);
            await etaFillDiscount(ETA.settings.discount);
            await Utils.sleep(delays.step);
        }

        if (ETA.settings.vat) {
            Utils.log(`صف ${index + 1}: إضافة ضريبة VAT...`);
            await etaAddTaxLine(ETA_SELECTORS.taxCodes.vat, delays);
            await Utils.sleep(delays.step);
        }

        if (ETA.settings.withholding) {

            const withholdingConfig =
                ETA.settings.withholdingType === "services"
                    ? ETA_SELECTORS.taxCodes.withholdingServices
                    : ETA_SELECTORS.taxCodes.withholdingSupplies;

            Utils.log(`صف ${index + 1}: إضافة ضريبة استقطاع...`);
            await etaAddTaxLine(withholdingConfig, delays);
            await Utils.sleep(delays.step);

        }

        Utils.log(`صف ${index + 1}: الضغط على أضف...`);
        await etaClickAdd(delays);
        Utils.log(`صف ${index + 1}: تم ✔`);

    }

    async function etaRunImport() {

        const delays = etaGetDelay();

        for (let i = 0; i < etaRows.length; i++) {

            if (ETA.stopped || !ETA_LICENSE_ACTIVE) { ETA.stopped = true; break; }

            await etaWaitWhilePaused();
            if (ETA.stopped || !ETA_LICENSE_ACTIVE) { ETA.stopped = true; break; }

            const row = etaRows[i];

            try {

                await Utils.retry(
                    () => etaProcessRowOnce(row, i, delays),
                    3,
                    1000
                );

            } catch (ex) {

                Utils.error(`Row ${i + 1} failed: ${ex.message || ex}`);
                etaAddLogEntry(i, row, ex.message || String(ex), "error");

            }

            ETA.current = i + 1;
            etaUpdateProgress();

        }

        etaFinishImport();

    }

    document.getElementById("eta-start").onclick = function () {

        if (!ETA_LICENSE_ACTIVE) {
            alert("الإضافة مش مفعّلة - فعّلها من موقع المكتب أولاً");
            return;
        }

        if (!ETA.file || etaRows.length === 0) {
            alert("من فضلك اختر ملف Excel أولاً");
            return;
        }

        if (typeof ETA_SELECTORS === "undefined") {
            alert("ملف selectors.js غير محمّل بشكل صحيح");
            return;
        }

        etaCollectSettings();

        ETA.running = true;
        ETA.paused = false;
        ETA.stopped = false;
        ETA.current = 0;
        ETA.total = etaRows.length;
        ETA.errorLog = [];

        document.getElementById("eta-log-list").innerHTML = "";
        document.getElementById("eta-log-box").style.display = "none";
        document.getElementById("eta-mini-log").innerHTML = "";

        document.getElementById("eta-start").disabled = true;
        document.getElementById("eta-start").innerText = "جاري الاستيراد...";
        document.getElementById("eta-actions-row").style.display = "flex";
        document.getElementById("eta-pause-btn").innerText = "Pause";

        document.getElementById("eta-close").style.display = "none";
        document.getElementById("eta-pause").innerText = "Pause";

        etaShowProgress();
        etaUpdateProgress();

        document.getElementById("eta-pause-btn").onclick = etaTogglePause;
        document.getElementById("eta-stop-btn").onclick = etaStopImport;

console.log("ETA Settings:", ETA.settings);
console.log("Rows:", etaRows.length);
        etaRunImport();

    };

    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

        if (request.action === "TOGGLE_SIDEBAR") {
            sidebar.classList.toggle("open");
            sendResponse({ success: true });
        }

        if (request.action === "ETA_ACTIVATE_OK") {
            ETA_LICENSE_ACTIVE = true;
            etaApplyLicenseUI();
            sendResponse({ success: true });
        }

        if (request.action === "ETA_DEACTIVATE") {
            ETA_LICENSE_ACTIVE = false;
            etaApplyLicenseUI();
            if (ETA.running) {
                ETA.stopped = true;
                const startBtn = document.getElementById("eta-start");
                if (startBtn) {
                    startBtn.disabled = false;
                    startBtn.innerText = "START IMPORT";
                }
            }
            sidebar.classList.remove("open");
            sendResponse({ success: true });
        }

        return true;

    });

})();