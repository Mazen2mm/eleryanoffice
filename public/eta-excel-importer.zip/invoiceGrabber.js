function addScript(src) {
    const script = document.createElement("script");
    script.type = "text/javascript";
    script.src = chrome.runtime.getURL(src);
    script.defer = "defer";
    (document.body || document.head || document.documentElement).appendChild(script);
}

function addCSS(src) {
    const link = document.createElement("link");
    link.rel = 'stylesheet';
    link.type = "text/css";
    link.href = chrome.runtime.getURL(src);

    (document.body || document.head || document.documentElement).appendChild(link);
}

addScript("helperCore.js");
addScript("jszip.min.js");
addScript("polyfill.js");
addScript("exceljs.min.js");
addCSS("css/bootstrap.min.css");
addCSS("css/pdf-grabber-style.css");
