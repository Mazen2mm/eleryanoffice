
chrome.runtime.sendMessage({ action: "GET_LICENSE_STATUS" }, (response) => {
    const el = document.getElementById("licenseStatus");
    if (!el) return;
    if (response && response.active) {
        el.textContent = "✅ الإضافة مفعّلة حاليًا";
        el.style.color = "#2ecc71";
    } else {
        el.textContent = "🔒 الإضافة مش مفعّلة - فعّلها من موقع المكتب (صفحة الإكستنشنز)";
        el.style.color = "#e74c3c";
    }
});

document.getElementById("toggleSidebar").addEventListener("click", () => {

    const status = document.getElementById("status");
    status.innerText = "";

    chrome.runtime.sendMessage(
        { action: "TOGGLE_SIDEBAR" },
        (response) => {

            if (chrome.runtime.lastError) {
                status.innerText = "تأكد إنك فاتح صفحة documentSubmission";
                return;
            }

            if (!response?.success) {
                status.innerText = response?.message || "افتح صفحة ETA أولاً";
            } else {
                window.close();
            }

        }
    );

});
